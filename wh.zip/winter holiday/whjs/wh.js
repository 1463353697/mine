// window.onload = function() {
// 	var xmlhttp = null;
// 	if (window.XMLHttpRequest) {
// 		xmlhttp = new XMLHttpRequest();
// 	} else {
// 		xmlhttp = new ActiveXObject("MicrosOft.XMLHTTP");
// 	}
// 	xmlhttp.open("GET","http://rapapi.org/mockjsdata/31832/www.uisdc.com",true);
//     xmlhttp.send("");
//     xmlhttp.onreadystatechange = function(){
//     	if(xmlhttp.readyState==4) {
//     		//连接服务器成功
//     		if (xmlhttp.status>=200&&xmlhttp.status<300||xmlhttp.status==304) {
//     			var imgs = JSON.parse(xmlhttp.responseTEXT);
//                 document.getElementById("listimgs").innerHTML = "<img src'"+imgs.img1+"'>"
//     		} else {
//     			alert("请求失败！")
//     		}
//     	}
//     }  
// }


window.onload = function(){
	var xmlhttp = null;
	if(window.XMLHttpRequest){
		xmlhttp = new XMLHttpRequest();
	}
	else{
		xmlhttp = new ActiveXObject("MicrosOft.XMLHTTP");
	}
//连接服务器
     xmlhttp.open("GET","http://rapapi.org/mockjs/31832/www.uisdc.com",true); 

//发送数据或请求
	 xmlhttp.send("");
//监听响应状态
	xmlhttp.onreadystatechange=function(){	
		if(xmlhttp.readyState==4){ //连接服务器成功
			//判断服务器响应状态
			if(xmlhttp.status>=200&&xmlhttp.status<300||xmlhttp.status==304){
	 	    var images = JSON.parse(xmlhttp.responseText)  
	 		document.getElementById("listimgs").innerHTML ="<img src='"+images.img1+"'>"
	 		+ "<img src='"+images.img1+"'>"
	 		+ "<img src='"+images.img2+"'>"
	 		+ "<img src='"+images.img3+"'>"
	 		+ "<img src='"+images.img4+"'>"
	 		+ "<img src='"+images.img5+"'>"
	 		+ "<img src='"+images.img6+"'>"
	 		+ "<img src='"+images.img7+"'>"
	 		+ "<img src='"+images.img7+"'>"
	 		 
	 		

	 		 

			
			}
			else{
				alert("请求失败!");
			}
		}
	}
	var list = document.getElementById('listimgs');
	var prev = document.getElementById('prev');
    var next = document.getElementById('next');

    function change(get) {
                
        var newLeft = parseInt(list.style.left) + get;
        list.style.left = newLeft + 'px';
        if(newLeft<-6825){
            list.style.left = -975 + 'px';
        }
        if(newLeft>-975){
            list.style.left = -6825 + 'px';
        }
    }

    prev.onclick = function() {             
        change(975);
    }
    next.onclick = function() {  
        change(-975);
    }
    var timer;
    function play() {
        timer = setInterval(function () {
        prev.onclick()
        }, 1500)
    }
    play();
    var container = document.getElementById('imgscontainer');

    function stop() {
        clearInterval(timer);
    }
    container.onmouseover = stop;
    container.onmouseout = play;
	
}
